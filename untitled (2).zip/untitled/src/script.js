// Activity Data (Static JSON)
let activities = [
    { id: 1, name: "Wake up early", completed: false },
    { id: 2, name: "Exercise", completed: false },
    { id: 3, name: "Study JavaScript", completed: false },
    { id: 4, name: "Drink Water", completed: false },
    { id: 5, name: "Read Book", completed: false }
];

const list = document.getElementById("activityList");
const progress = document.getElementById("progress");

// Render Activities
function renderActivities() {
    list.innerHTML = "";

    activities.forEach((activity, index) => {
        const li = document.createElement("li");

        li.className = activity.completed ? "completed" : "";

        li.innerHTML = `
            ${activity.name}
            <input type="checkbox" 
            ${activity.completed ? "checked" : ""}
            onchange="toggleStatus(${index})">
        `;

        list.appendChild(li);
    });

    updateProgress();
}

// Toggle Status
function toggleStatus(index) {
    activities[index].completed = !activities[index].completed;
    renderActivities();
}

// Update Progress
function updateProgress() {
    let completed = activities.filter(a => a.completed).length;
    progress.innerText = `${completed} out of ${activities.length} completed`;
}

// Initial Load
renderActivities();